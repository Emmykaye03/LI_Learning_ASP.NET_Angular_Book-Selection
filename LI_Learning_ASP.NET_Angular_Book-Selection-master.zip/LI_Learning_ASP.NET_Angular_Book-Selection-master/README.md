# LI_Learning_ASP.NET_Angular_Book-Selection
A CRUD Application Using ASP.NET, Angular, C# with CLI<br/>
This application is based on the application created during the <a href="https://www.linkedin.com/learning/building-angular-and-asp-dot-net-core-applications">Building Angular and ASP.NET Core Applications</a> class on Linkedin Learning. 


Overview of topics learned: 
<ul>
<li>Web API Architecture</li>
<li>Angular API Architecture</li>
<li>NgRx</li>
<li>Authentication Implimentation</li>
  </ul>
