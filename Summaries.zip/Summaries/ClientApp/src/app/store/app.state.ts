export interface AppState
{
    readonly books: Book[];
}